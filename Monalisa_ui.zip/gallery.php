<?php include('layouts/header.php'); ?>
<main>
    <!--start banner section-->
    <section class="gallery-banner">
        <div class="overlay">
            <div class="banner-text">
                <h1 class="fw-bold white-txt-color text-center">Gallery</h1>
                <p class="text-center white-txt-color">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
            </div>
        </div>
    </section>
    <!--end banner section-->
<!--    the image section-->
    <section class="grid-wrap">
        <ul class="grid swipe-down" id="grid">

            <li><a href="#"><img src="SiteAssets/images/pexels-hazem-omar-10632137%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-thais-cordeiro-3873669%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-дмитрий-трепольский-8285167%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-davi-pimentel-2064827%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-engin-akyurt-2828283%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-andrew-neel-3201763%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-pixabay-54081%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-aleksandar-pasaric-2506923%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-timo-volz-3769312%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-hazem-omar-10632137%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-thais-cordeiro-3873669%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-дмитрий-трепольский-8285167%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-davi-pimentel-2064827%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-engin-akyurt-2828283%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-andrew-neel-3201763%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-pixabay-54081%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-aleksandar-pasaric-2506923%201.png" alt="dummy"></a></li>
            <li><a href="#"><img src="SiteAssets/images/pexels-timo-volz-3769312%201.png" alt="dummy"></a></li>
        </ul>
    </section>
</main>
<?php include('layouts/footer.php'); ?>