<?php include('layouts/header.php'); ?>
<main>
    <!--start banner section-->
    <section class="banner">
        <div class="overlay">
            <div class="banner-text">
                <h1 class=" white-txt-color text-center">See some benifit of joining us.</h1>
                <p class="fw-bold white-txt-color">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            </div>
            <!--            social media icons-->
            <div class="social-media">
                <i class="bi bi-facebook"></i>
                <i class="bi bi-twitter"></i>
                <i class="bi bi-instagram"></i>

            </div>
        </div>
    </section>
    <!--end banner section-->
<!--    start counter-->
    <section class="deals">
        <div class="container">
            <div class="counter">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="single-box">
                            <p class="title ">TRAVELLER</p>
                            <p class="number">3562</p>
                        </div>
                    </div><div class="col-md-3 col-sm-6">
                        <div class="single-box">
                            <p class="title ">TRAVELLER</p>
                            <p class="number">3562</p>
                        </div>
                    </div><div class="col-md-3 col-sm-6">
                        <div class="single-box">
                            <p class="title ">TRAVELLER</p>
                            <p class="number">3562</p>
                        </div>
                    </div><div class="col-md-3 col-sm-6">
                        <div class="single-box">
                            <p class="title ">TRAVELLER</p>
                            <p class="number">3562</p>
                        </div>
                    </div>
                </div>
            </div>
           <div class="padding">
               <h1 class="text-center">Get best deals</h1>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                   Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                   Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
           </div>
        </div>
    </section>
<!--    end counter-->
</main>
<?php include('layouts/footer.php'); ?>